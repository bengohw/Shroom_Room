# ESP Diagnostics Data Store

[![Component Registry](https://components.espressif.com/components/espressif/esp_diag_data_store/badge.svg)](https://components.espressif.com/components/espressif/esp_diag_data_store)

This is an abstraction layer for ESP Diagnostics Data Storage. It may use RTC memory, Flash, RAM, etc.

