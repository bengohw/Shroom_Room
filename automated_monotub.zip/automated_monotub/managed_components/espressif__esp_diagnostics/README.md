# ESP Diagnostics Component

[![Component Registry](https://components.espressif.com/components/espressif/esp_diagnostics/badge.svg)](https://components.espressif.com/components/espressif/esp_diagnostics)

This component provides the diagnostics functionality used by [ESP Insights](https://github.com/espressif/esp-insights).
