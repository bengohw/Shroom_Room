# ESP Insights Agent Component

[![Component Registry](https://components.espressif.com/components/espressif/esp_insights/badge.svg)](https://components.espressif.com/components/espressif/esp_insights)

This is the main firmware agent for ESP Insights, which will then pull in other required comoponents. Please check the [ESP Insights documentation](https://github.com/espressif/esp-insights) for details.

