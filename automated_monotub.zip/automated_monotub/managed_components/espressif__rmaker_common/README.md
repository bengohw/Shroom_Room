# ESP RainMaker Common modules

This component consists of some common modules used by ESP RainMaker and ESP RainMaker Diagnostics repos.
Currently, it consists of
- MQTT glue layer
- Timing APIs (SNTP helpers, timezone, etc.)
- Factory NVS helpers
- Work Queue

